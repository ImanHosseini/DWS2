CREATE VIEW highscore AS
  SELECT player.username,
    player.level
   FROM player
  ORDER BY player.level DESC
 LIMIT 10;

