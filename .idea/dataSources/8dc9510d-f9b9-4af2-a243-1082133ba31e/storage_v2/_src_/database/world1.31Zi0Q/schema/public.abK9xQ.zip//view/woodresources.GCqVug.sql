CREATE VIEW woodresources AS
  SELECT resource.r_id,
    resource.r_type,
    resource.r_val,
    resource.r_pos,
    resource.r_owner
   FROM resource
  WHERE ((resource.r_type)::text = 'WOOD'::text);

